package com.example.myapplication

data class PetsData(
    val pet_name: String,
    val pet_age: String,
    val pet_mood: String
)