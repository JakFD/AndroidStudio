package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        this.resources

        binding.button2.setOnClickListener {
            startActivity(Intent(this, MainActivity2::class.java))
        }

        binding.button3.setOnClickListener {
            startActivity(Intent(this, MainActivity3::class.java))
        }

        binding.button4.setOnClickListener {
                startActivity(Intent(this, MainActivity4::class.java))
        }

        val pets = listOf(
            PetsData("Mikolay", "7", "friendly"),
            PetsData("Stepan", "11", "angry"),
            PetsData("Taras", "9", "confused")
        )
    }
}