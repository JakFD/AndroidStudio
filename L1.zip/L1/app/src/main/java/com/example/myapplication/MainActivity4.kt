package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        val pets = listOf(
            PetsData("Taras", "9", "confused"))

//////////////Вибачте, але я так i не знайшов як з listof(dataclass) вписати у textview

        val myTextView = findViewById<TextView>(R.id.textView19)
        myTextView.text = "Taras"

        val myTextView2 = findViewById<TextView>(R.id.textView20)
        myTextView2.text = "9"

        val myTextView3 = findViewById<TextView>(R.id.textView21)
        myTextView3.text = "confused"
    }
}