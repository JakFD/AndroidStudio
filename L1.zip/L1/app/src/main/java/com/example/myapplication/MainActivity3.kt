package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val pets = listOf(
            PetsData("Stepan", "11", "angry"))

//////////////Вибачте, але я так i не знайшов як з listof(dataclass) вписати у textview

        val myTextView = findViewById<TextView>(R.id.textView13)
        myTextView.text = "Stepan"

        val myTextView2 = findViewById<TextView>(R.id.textView14)
        myTextView2.text = "11"

        val myTextView3 = findViewById<TextView>(R.id.textView15)
        myTextView3.text = "angry"
    }
}