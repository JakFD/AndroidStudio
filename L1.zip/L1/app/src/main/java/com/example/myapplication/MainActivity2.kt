package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val pets = listOf(
            PetsData("Mikolay", "7", "friendly"))

//////////////Вибачте, але я так i не знайшов як з listof(dataclass) вписати у textview

        val myTextView = findViewById<TextView>(R.id.textView7)
        myTextView.text = "Mikolay"

        val myTextView2 = findViewById<TextView>(R.id.textView8)
        myTextView2.text = "7"

        val myTextView3 = findViewById<TextView>(R.id.textView9)
        myTextView3.text = "friendly"
}}